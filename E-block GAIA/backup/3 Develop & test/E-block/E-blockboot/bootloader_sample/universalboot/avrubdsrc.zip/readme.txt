Readme

1.Compiler

I use Delphi to develop this software. Project can be compile use
Delphi5 and Delphi7, other version have not tested.


2.Used components:

Before you load project file, you must install these components:
HighResTime, BtBeep, CPort, HexEdit, SynEdit.

These components can be found below:

http://www.torry.net/vcl/datetime/timers/rlhighrestimer.zip
http://www.torry.net/vcl/sound/pcspeaker/btbeeper.zip
http://sourceforge.net/projects/comport/
http://www.haoxg.net/download/hexedit.zip
http://synedit.sourceforge.net


3.Contact

If you have any suggestion, please send email to me. You may get
last version of this project at:

http://shaoziyang.googlepages.com
http://shaoziyang.bloger.com.cn


by Shao ziyang
2007.6
