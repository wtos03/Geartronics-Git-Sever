/*
             BUTTLOAD - Butterfly ISP Programmer
				
              Copyright (C) Dean Camera, 2006.
                  dean_camera@hotmail.com
*/

#include "ProgDataflash.h"

// ======================================================================================

void PD_InterpretAVRISPPacket(void)
{
	switch (PacketBytes[0])
	{
		case CMD_ENTER_PROGMODE_ISP:
			MessageSize = 2;
			
			DF_ENABLEDATAFLASH(TRUE);
			DF_GetChipCharacteristics();

			if (DataflashInfo.PageBits)
			{
				InProgrammingMode = TRUE;                  // Set the flag, prevent the user from exiting the V2P state machine			
				MAIN_SETSTATUSLED(RED);
				PacketBytes[1] = STATUS_CMD_OK;
			}
			else
			{
				DF_ENABLEDATAFLASH(FALSE);
				PacketBytes[1] = STATUS_CMD_FAILED;
			}
			
			break;			
		case CMD_LEAVE_PROGMODE_ISP:
			MessageSize = 2;

			InProgrammingMode = FALSE;                     // Clear the flag, allow the user to exit the V2P state machine

			DF_ENABLEDATAFLASH(FALSE);
			MAIN_SETSTATUSLED(GREEN);
			PacketBytes[1] = STATUS_CMD_OK;

			break;
		case CMD_READ_SIGNATURE_ISP:
			MessageSize = 4;

			PacketBytes[1] = STATUS_CMD_OK;                // Data byte is encased in CMD_OKs
			PacketBytes[2] = 0x02;                         // Signature bytes all return "02" in program dataflash mode
			PacketBytes[3] = STATUS_CMD_OK;                // Data byte is encased in CMD_OKs

			break;
		case CMD_CHIP_ERASE_ISP:
			MessageSize = 2;

			for (uint16_t PageToErase = 0; PageToErase < DataflashInfo.TotalPages; PageToErase++)
			   DF_ErasePage(PageToErase);

			PacketBytes[1] = STATUS_CMD_OK;
			
			break;
		case CMD_READ_OSCCAL_ISP:
		case CMD_READ_FUSE_ISP:
		case CMD_READ_LOCK_ISP:
			MessageSize = 4;

			PacketBytes[1] = STATUS_CMD_OK;               // Data byte is encased in CMD_OKs
			PacketBytes[2] = 0xFF;                        // Return 0xFFs for the bytes since they're not applicable
			PacketBytes[3] = STATUS_CMD_OK;               // Data byte is encased in CMD_OKs

			break;
		case CMD_PROGRAM_FUSE_ISP:
		case CMD_PROGRAM_LOCK_ISP:
			MessageSize = 3;
			
			PacketBytes[1] = STATUS_CMD_OK;               // Two CMD_OKs are always returned
			PacketBytes[2] = STATUS_CMD_OK;               // Two CMD_OKs are always returned

			break;
		case CMD_PROGRAM_FLASH_ISP:
			MessageSize = 2;

			PacketBytes[1] = STATUS_CMD_OK;
		
			break;
		case CMD_READ_FLASH_ISP:
			MessageSize = (((uint16_t)PacketBytes[1] << 8) | PacketBytes[2]) + 3;

			PacketBytes[1]               = STATUS_CMD_OK; // Return data should be encompassed in STATUS_CMD_OKs
			PacketBytes[MessageSize - 1] = STATUS_CMD_OK; // Return data should be encompassed in STATUS_CMD_OKs
		
			for (uint16_t DB = 1; DB < (MessageSize - 2); DB++)
			   PacketBytes[DB] = 0xFF;
		
			break;
		case CMD_PROGRAM_EEPROM_ISP:
			PD_SetupDFAddressCounters();
			
			DF_CopyFlashPageToBuffer(CurrPageAddress);
			DF_BufferWriteEnable(CurrBuffByte);
			
			uint16_t BytesToWrite = ((uint16_t)PacketBytes[1] << 8)
			                      | PacketBytes[2];

			for (uint16_t WriteByte = 0; WriteByte < BytesToWrite; WriteByte++)
			{
				DF_StoreDataflashByte(PacketBytes[10 + WriteByte]);
				CurrBuffByte++;
				V2P_IncrementCurrAddress();
			}

			PacketBytes[1] = STATUS_CMD_OK;
		
			break;
		case CMD_READ_EEPROM_ISP:
			PD_SetupDFAddressCounters();
			DF_ContinuousReadEnable(CurrAddress, CurrBuffByte);
			
			uint16_t BytesToRead = ((uint16_t)PacketBytes[1] << 8)
			                      | PacketBytes[2];
			
			for (uint16_t ReadByte = 0; ReadByte < BytesToRead; ReadByte++)
			{
				PacketBytes[2 + ReadByte] = USI_SPITransmit(0x00); // Read in the next dataflash byte if present
				V2P_IncrementCurrAddress();
			}
			
			MessageSize = BytesToRead + 3;

			PacketBytes[1]               = STATUS_CMD_OK; // Return data should be encompassed in STATUS_CMD_OKs
			PacketBytes[2 + BytesToRead] = STATUS_CMD_OK; // Return data should be encompassed in STATUS_CMD_OKs
			
			break;
		default:
			MessageSize = 1;
			
			PacketBytes[1] = STATUS_CMD_UNKNOWN;
	}

	V2P_SendPacket();                                   // Send the response packet
}

void PD_SetupDFAddressCounters(void)
{
	uint32_t StartAddress = CurrAddress;

	CurrPageAddress = 0;

	while (StartAddress > DataflashInfo.PageSize)      // This loop is the equivalent of a DIV and a MOD
	{
		StartAddress -= DataflashInfo.PageSize;         // Subtract one page's worth of bytes from the desired address
		CurrPageAddress++;
	}
	
	CurrBuffByte = (uint16_t)StartAddress;              // The buffer byte is the remainder
}

void DF_StoreDataflashByte(uint8_t Data)
{
	if (CurrBuffByte == DataflashInfo.PageSize)
	{
		DF_CopyBufferToFlashPage(CurrPageAddress++);
		DF_BufferWriteEnable(0);
		CurrBuffByte = 0;
	}
	
	USI_SPITransmit(Data);                                 // Store the byte, dataflash is in write mode due to DF_BufferWriteEnable
	CurrBuffByte++;
}
