/*
             BUTTLOAD - Butterfly ISP Programmer
				
                   By Dean Camera, 2005.
                  dean_camera@hotmail.com
*/

#ifndef SIGBYTES_H
#define SIGBYTES_H

// INCLUDES:
#include <avr/pgmspace.h>

// DEFINES AND MACROS:
#define LockedSigByte   0x00
#define TOTALDEVICES    1

// EXTERNAL VARIABLES:
extern const uint8_t  ChipLocked[] PROGMEM;
extern const uint8_t  UnknownID[]  PROGMEM;

// PROTOTYPES:
char* SigBytesToDevice(char BytesToMatch[]);

// EXTERNS:
extern const uint8_t  SigBytes[TOTALDEVICES][2] PROGMEM;
extern const uint8_t* DeviceNames[TOTALDEVICES] PROGMEM;

#endif
