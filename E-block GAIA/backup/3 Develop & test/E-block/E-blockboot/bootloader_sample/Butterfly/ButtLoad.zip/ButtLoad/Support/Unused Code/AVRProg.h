/*
             BUTTLOAD - Butterfly ISP Programmer
				
                   By Dean Camera, 2005.
                  dean_camera@hotmail.com
*/

// INCLUDES:
#include <AVR/io.h>
#include "usart.h"
#include "main.h"

// PROTOTYPES:
void InterpretAVRProgByte(void);
