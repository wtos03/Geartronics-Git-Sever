/*
             BUTTLOAD - Butterfly ISP Programmer
				
                   By Dean Camera, 2005.
                  dean_camera@hotmail.com
*/

#include <avr/io.h>
#include "Main.h"

/*  Prescaler value converted to bit settings. */
#define TC0_PS_1    (1<<CS00)
#define TC0_PS_8    (1<<CS01)
#define TC0_PS_64   (1<<CS01)|(1<<CS00)
#define TC0_PS_256  (1<<CS02)
#define TC0_PS_1024 (1<<CS02)|(1<<CS00)

/* Other Defines */
#define SPI_PRESET_SPEEDS 4

#define SSPI_TOGGLECLOCK()  Delay1MS(1); PINE ^= (1 << 4); Delay1MS(1); PINE ^= (1 << 4);

unsigned char SSPI_SPITransmit(uint8_t Data);
unsigned char SSPI_SPITransmitWord(uint16_t Data);
void SSPI_SPISetSpeed(uint8_t Freq);
