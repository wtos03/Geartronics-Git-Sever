/*
             BUTTLOAD - Butterfly ISP Programmer
				
              Copyright (C) Dean Camera, 2006.
                  dean_camera@hotmail.com
*/

#ifndef ISP_H
#define ISP_H

// INCLUDES:
#include <avr/io.h>

#include "ISPInterpreter.h"
#include "eeprom169.h"

// DEFINES:
#define HIGH      1
#define LOW       0

// PROTOTYPES:
void    ResetLine(char HighLow);
uint8_t SPI_Transmit(uint8_t Data);

#endif
