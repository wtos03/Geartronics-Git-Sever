/*
             BUTTLOAD - Butterfly ISP Programmer
				
                   By Dean Camera, 2005.
                  dean_camera@hotmail.com
*/

#include "SSPI.h"

volatile unsigned char DataTemp;
volatile unsigned char TimerSetupData;
volatile unsigned char SentBits;

SIGNAL(SIG_OUTPUT_COMPARE0)
{	
	if (PORTE & (1 << 4))     // Falling edge, setup
	{
		if (DataTemp & 0x80)   // MSB set
		   PORTE |= (1 << 6);  // Data line high
		else
		   PORTE &= ~(1 << 6); // Data line low

		DataTemp <<= 1;        // Shift the byte right by one bit
	}
	else                     // Rising edge, sample
	{
		if (PORTE & (1 << 5))
		   DataTemp |= 0x01;  // Load in the MISO data pin
		
		SentBits++;	// Increment the bits recieved counter
	}

	PINE ^= (1 << 4);        // Toggle the clock
}

unsigned char SSPI_SPITransmit(uint8_t Data)
{
	SentBits = 0;            // Reset the counter
	DataTemp = Data;         // Load the data into the storage variable
	TCCR0A = TimerSetupData; // Load the timer config data, and thus start the clock
	
	while (SentBits < 8) {};
	
	TCCR0A = 0;              // Stop the timer

	return DataTemp;
}

unsigned char SSPI_SPITransmitWord(uint16_t Data)
{
	SSPI_SPITransmit(Data >> 8);
	return SSPI_SPITransmit(Data);
}

void SSPI_SPISetSpeed(uint8_t Freq)
{                                            // SPI Clock Duration Value, Timer Prescale, Compare Value
	uint8_t PSValues[SPI_PRESET_SPEEDS][3]  = {{SPI_SPEED_921600Hz      , TC0_PS_1      , 30           },
	                                            {SPI_SPEED_230400Hz      , TC0_PS_1      , 42           },
	                                            {SPI_SPEED_57600Hz       , TC0_PS_1      , 53           },
	                                            {SPI_SPEED_28800Hz       , TC0_PS_1      , 64           }};
														   // SSPI Speed = (Fcpu/Prescale/Compare/2)Hz
	
	for (uint8_t MatchIndex = 0; MatchIndex < SPI_PRESET_SPEEDS; MatchIndex++)
	{
		if ((PSValues[MatchIndex][0] == Freq) | (MatchIndex == (SPI_PRESET_SPEEDS - 1)))
		{
			// Init Output Compare Register.
			OCR0A = PSValues[MatchIndex][2];

			// Enable 'Clear Timer on Compare match' and set prescaler - store the result in a variable
			TimerSetupData = ((1<<WGM01) | PSValues[MatchIndex][1]);
				
			return;
		}
	}
}
