#include "Timeout.h"

volatile uint8_t  Ticks   = 0;
volatile uint8_t  TimeOut = FALSE;

// ======================================================================================

ISR(TIMER1_OVF_vect, ISR_NOBLOCK)
{
	if (Ticks++ == 5)
	{
	   Ticks   = 0;
	   TimeOut = TRUE;
	}
}

// ======================================================================================

void TIMEOUT_SetupTimeoutTimer(void)
{
	TCCR1A = 0;
	TIMEOUT_TIMER_OFF();
	TCCR1C = 0;
	
	TIMSK1 = (1 << TOIE1); // Turn timer 1 overflow interrupt on
}
