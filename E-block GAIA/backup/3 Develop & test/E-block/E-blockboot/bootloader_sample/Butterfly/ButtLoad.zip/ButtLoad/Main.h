/*
             BUTTLOAD - Butterfly ISP Programmer
				
              Copyright (C) Dean Camera, 2006.
                  dean_camera@hotmail.com
*/

#ifndef MAIN_H
#define MAIN_H

// TYPE DEFINITIONS:
typedef void (*FuncPtr)(void);

// INCLUDES:
#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/pgmspace.h>
#include <avr/interrupt.h>
#include <avr/version.h>
#include <util/delay.h>
#include <string.h>
#include <inttypes.h>

#include "ISRMacro.h"
#include "OSCCal.h"
#include "LCD_Functions.h"
#include "LCD_Driver.h"
#include "V2Protocol.h"
#include "USART.h"
#include "SPI.h"
#include "USI.h"
#include "Dataflash.h"
#include "ProgDataflash.h"
#include "ProgramManager.h"
#include "RingBuff.h"
#include "EEPROMVariables.h"

// LIB C VERSION CHECK:

#ifdef __AVR_LIBC_VERSION__
 #if (__AVR_LIBC_VERSION__ < 10401UL) // In future requirements may be increased with changes
  #error AVRLibC Version 1.4.1 or higher is required to compile this project.
 #endif
#else
 #error AVRLibC Version 1.4.1 or higher is required to compile this project.
#endif

// EXTERNAL VARIABLES:
extern const uint8_t ProgrammerName[];
extern const uint8_t VersionInfo[];
extern const uint8_t FAULTERR_Short[];
#define JoyStatus GPIOR0 // Pseudo-variable; "JoyStatus" becomes an alias for the General Purpose IO Storage Register 0

// DEFINES AND MACROS:
#define VERSION_MAJOR 0
#define VERSION_MINOR 7

#define MAGIC_NUM  0b01011010 // Magic number, used for first-run detection

#define MAIN_SETSTATUSLED(mask) PORTF = ((PORTF & ~(GREEN | RED)) | (mask))
#define GREEN      (1 << 4)
#define ORANGE     ((1 << 4) | (1 << 5))
#define RED        (1 << 5)

#define JOY_LEFT   (1 << 2)
#define JOY_RIGHT  (1 << 3)
#define JOY_UP     (1 << 6)
#define JOY_DOWN   (1 << 7)
#define JOY_PRESS  (1 << 4)
#define JOY_BMASK  ((1 << 4) | (1 << 6) | (1 << 7))
#define JOY_EMASK  ((1 << 2) | (1 << 3))

#define TC2_PS_OFF  0
#define TC2_PS_1    (1 << CS20)
#define TC2_PS_8    (1 << CS21)
#define TC2_PS_32   ((1 << CS20) | (1 << CS21))
#define TC2_PS_64   (1 << CS22)
#define TC2_PS_128  ((1 << CS20) | (1 << CS22))
#define TC2_PS_256  ((1 << CS21) | (1 << CS22))
#define TC2_PS_1024 ((1 << CS20) | (1 << CS21) | (1 << CS22))

#define TRUE        1
#define FALSE       0
#define HIGH        TRUE
#define LOW         FALSE

// PROTOTYPES:
void Delay10MS(uint8_t loops);
void Delay1MS(uint8_t loops);
void MAIN_ResetLine(uint8_t HighLow);
void MAIN_WaitForJoyRelease(void);
void MAIN_IntToStr(uint16_t IntV, uint8_t* Buff);
void MAIN_ShowProgType(uint8_t Letter);
void MAIN_ShowError(const char *pFlashStr);
void FUNCChangeSettings(void);
void FUNCShowAbout(void);
void FUNCAVRISPMode(void);
void FUNCProgramDataflash(void);
void FUNCProgramAVR(void);
void FUNCStoreProgram(void);
void FUNCClearMem(void);
void FUNCManCalib(void);
void FUNCSetContrast(void);
void FUNCSetISPSpeed(void);

#endif
