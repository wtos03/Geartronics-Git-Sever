/*
             BUTTLOAD - Butterfly ISP Programmer
				
              Copyright (C) Dean Camera, 2006.
                  dean_camera@hotmail.com
*/

#ifndef ISPCHIPCOMM_H
#define ISPCHIPCOMM_H

// INCLUDES:
#include <avr/io.h>
#include <avr/pgmspace.h>
#include <util/delay.h>

#include "Main.h"
#include "lcd_functions.h"
#include "lcd_driver.h"
#include "eeprom169.h"
#include "SPI.h"
#include "USI.h"
#include "AVRISPCommandBytes.h"

// MACROS AND DEFINES:
#define PROG_MODE_PAGE              0x01
#define PROG_MODE_PAGEDONE          0x80
#define POLL_MODE_AVR               0x03

#define POLL_BUSYFLAG               0x01

#define PAGE_POLLTYPE_MASK          0x70
#define PAGE_POLLTYPE_MASKSHIFT     4
#define PAGE_POLLTYPE_WAIT          (1 << 4)

#define WORD_POLLTYPE_MASK          0x0E
#define WORD_POLLTYPE_MASKSHIFT     1
#define WORD_POLLTYPE_WAIT          (1 << 1)

#define POLLTYPE_MASK               0x07
#define POLLTYPE_WAIT               (1 << 0)
#define POLLTYPE_DATA               (1 << 1)
#define POLLTYPE_READY              (1 << 2)

#define HIGH_BYTE_READ              (1 << 3)
#define LOW_BYTE_READ               (0 << 3)
#define HIGH_BYTE_WRITE             (1 << 3)
#define LOW_BYTE_WRITE              (0 << 3)

#define LOAD_EXTENDED_ADDR_CMD      0x4D

#define NO_FAULT                    0
#define FAULT_SHORT                 1

// EXTERNAL VARIABLES:
extern const uint8_t SyncErrorMessage[] PROGMEM;

// PROTOTYPES:
void   ISPCC_EnterChipProgrammingMode(void);
void   ISPCC_ProgramChip(void);
void   ISPCC_PollForProgComplete(uint8_t PollData, uint16_t PollAddr);
uint8_t ISPCC_CheckForCableFaults(void);
uint8_t CheckUSIShort(uint8_t BitMask);

#endif
