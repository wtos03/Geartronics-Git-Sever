/*
             BUTTLOAD - Butterfly ISP Programmer
				
                   By Dean Camera, 2005.
                  dean_camera@hotmail.com
*/

#include "AVRProg.h"

// GLOBAL VARIABLES:
const uint8_t ProgrammerID[] PROGMEM = "AVRBOOT";

// ======================================================================================

void InterpretAVRProgByte(void)
{
	unsigned long address;
	unsigned char val;

	val=UDR;

	// Check autoincrement status.
	if(val=='a')
	{
		Usart_Tx('Y'); // Yes, we do autoincrement.
	}
	
	// Set address.
	else if(val=='A') // Set address...
   { // NOTE: Flash addresses are given in words, not bytes.
		address=((Usart_Rx()<<8) | Usart_Rx()); // Read address high and low byte.
		Usart_Tx('\r'); // Send OK back.
	}

	// Chip erase.
	else if(val=='e')
	{
		// TODO: Add erase code
		Usart_Tx('\r'); // Send OK back.
	}

	// Enter programming mode.
	else if(val=='P')
	{
		ResetLine(LOW);
		SetStatusLED(RED);
		Usart_Tx('\r'); // Nothing special to do, just answer OK.
	}

	// Leave programming mode, or exit bootloader.
	else if(val=='L' || val=='E')
	{
		ResetLine(HIGH);
		SetStatusLED(GREEN);
		Usart_Tx('\r'); // Nothing special to do, just answer OK.
	}

	// Get programmer type.
	else if (val=='p')
	{
		Usart_Tx('S'); // Answer 'SERIAL'.
	}

	// Return supported device codes.
	else if (val=='t')
	{
		for (uint8_t DevID = 0; DevID < TOTALDEVICES; DevID++)
			Usart_Tx(SigBytes[DevID][4]); // Send support list
		
		Usart_Tx( 0 ); // Send list terminator.
	}

	// Set LED, clear LED and set device type.
	else if((val=='x')||(val=='y')||(val=='T'))
	{
		Usart_Rx();     // Ignore the command and it's parameter.
		Usart_Tx('\r'); // Send OK back.
	}
	
	// Return programmer identifier.
	else if(val=='S')
	{
		for(val=0x00; val<7; val++)
			Usart_Tx(pgm_read_byte(&ProgrammerID[val])); // Send 7-byte programmer ID name
	}

	// Return software version.
	else if(val=='V')
	{
		Usart_Tx(1);
		Usart_Tx(5);
	}

	// Return signature bytes.
	else if(val=='s')
	{							
		// TODO: Add signature byte retrival code
//		Usart_Tx( SIGNATURE_BYTE_3 );
//		Usart_Tx( SIGNATURE_BYTE_2 );
//		Usart_Tx( SIGNATURE_BYTE_1 );
	}

	// The last command to accept is ESC (synchronization).
	else if(val!=0x1b)                  // If not ESC, then it is unrecognized...
	{
		Usart_Tx('?');
   }
}
