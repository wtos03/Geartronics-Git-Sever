/*
             BUTTLOAD - Butterfly ISP Programmer
				
                   By Dean Camera, 2005.
                  dean_camera@hotmail.com
*/

#include "SigBytes.h"

const uint8_t  ChipLocked[] PROGMEM = "CHIPLOCKD";
const uint8_t  UnknownID[]  PROGMEM = "UNKCHIP";
const uint8_t  M8515[]      PROGMEM = "M8515";

// SIGBYTE1, SIGBYTE2, DEVNAMEINDEX, PARTCODE, 
const uint8_t  SigBytes[TOTALDEVICES][2] PROGMEM =
{
	{0x93, 0x01}
};

const uint8_t* DeviceNames[TOTALDEVICES] PROGMEM =
{
	M8515
};

// ======================================================================================

char* SigBytesToDevice(char BytesToMatch[])
{
	if (BytesToMatch[0] == LockedSigByte) // If the first byte indicates a locked chip, exit the function
		return 0;

	for(uint8_t SearchD = 0; SearchD < TOTALDEVICES; SearchD++)
	{
		for(uint8_t MatchByte = 0; MatchByte < 3; MatchByte++)
		{
			if (pgm_read_byte(SigBytes[SearchD][MatchByte]) != BytesToMatch[MatchByte])
				break;
			else if (MatchByte == 2)
				return (char*)pgm_read_word(DeviceNames[SearchD]);
		}
	}
	
//	return (char*)&UnknownID; // Unknown chip, return the unknown chip text
	return 0;
}
