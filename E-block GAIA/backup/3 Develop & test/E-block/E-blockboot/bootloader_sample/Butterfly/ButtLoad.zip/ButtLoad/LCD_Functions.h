//
//  Author(s)...: ATMEL Norway
//
//  Target(s)...: ATmega169
//

#ifndef LCD_FUNCTIONS_H
#define LCD_FUNCTIONS_H

// INCLUDES:
#include <avr/pgmspace.h>

// DEFINES:
#define SCROLL    1
#define NOSCROLL  0

// PROTOTYPES:
void LCD_puts_f(const char *pFlashStr, char scrollmode);
void LCD_puts(char *pStr, char scrollmode);
void LCD_UpdateRequired(char update, char scrollmode);
void LCD_putc(uint8_t digit, char character);
void LCD_Clear(void);

#endif
