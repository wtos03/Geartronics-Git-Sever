/*
             BUTTLOAD - Butterfly ISP Programmer
				
              Copyright (C) Dean Camera, 2006.
                  dean_camera@hotmail.com
*/

#ifndef PGMMGR_H
#define PGMMGR_H

// INCLUDES:
#include <avr/io.h>

#include "Main.h"
#include "Dataflash.h"
#include "AVRISPCommandBytes.h"
#include "EEPROMVariables.h"


// DEFINES:
#define NO_SETUP           0
#define DATAFLASH_WRITE    1
#define DATAFLASH_READ     2
#define LOCKFUSEBITS_WRITE 3
#define LOCKFUSEBITS_READ  4

#define TYPE_EEPROM        0
#define TYPE_FLASH         1
#define TYPE_FUSE          2
#define TYPE_LOCK          3

#define PAGELENGTH_FOUNDBIT (uint16_t)(1 << 15)

#define MAX_FUSELOCKBITS   10

#define EEPROM_OFFSET      (uint32_t)(1024UL * 257UL)

// PROTOTYPES:
uint32_t PM_GetStoredDataSize(uint8_t Type);
void     PM_SetupDFAddressCounters(uint8_t Type);
void     PM_StoreProgramByte(uint8_t Data);
void     PM_InterpretAVRISPPacket(void);
void     PM_CheckEndOfProgramming(void);
void     PM_CheckEndOfFuseLockStore(void);
void     PM_SendFuseLockBytes(uint8_t Type);
void     PM_SendEraseCommand(void);
void     PM_CreateProgrammingPackets(uint8_t Type);

#endif
