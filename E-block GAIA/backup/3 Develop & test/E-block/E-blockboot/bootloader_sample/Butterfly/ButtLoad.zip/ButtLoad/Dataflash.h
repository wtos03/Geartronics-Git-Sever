/*
             BUTTLOAD - Butterfly ISP Programmer
				
              Copyright (C) Dean Camera, 2006.
                  dean_camera@hotmail.com
*/

#ifndef DATAFLASH_H
#define DATAFLASH_H

// TYPE DEFINITIONS:
typedef unsigned char (*SPIFuncPtr)(unsigned char);

typedef struct
{
	unsigned char PageBits;
	unsigned int  PageSize;
	unsigned int  TotalPages;
} DFinfo;

// INCLUDES:
#include <avr/io.h>

#include "Main.h"
#include "DataflashCommandBytes.h"

// DEFINES AND MACROS:
#define DF_ENABLEDATAFLASH(tf)   if (tf) { PORTF &= ~(1 << 9); PORTB &= ~(1 << 0); } else { PORTF |= (1 << 9); PORTB |= (1 << 0); }
#define DF_TOGGLEENABLE()        DF_ENABLEDATAFLASH(FALSE); asm volatile ("nop"::); DF_ENABLEDATAFLASH(TRUE)
#define DF_BUSY()                !(DF_GetChipCharacteristics() & DF_BUSYMASK)

#define DF_BUSYMASK              0x80
#define DF_INTERNALDF_BUFFBYTES  264

#define PageShiftHigh            GPIOR1 // Psuedo variable; linked to the General Purpose Storage register 1 for speed
#define PageShiftLow             GPIOR2 // Psuedo variable; linked to the General Purpose Storage register 2 for speed

#define DF_SENDSPIBYTE(data)     (DFSPIRoutinePointer)(data)

// GLOBAL VARIABLES:
extern SPIFuncPtr DFSPIRoutinePointer;
extern DFinfo     DataflashInfo;
extern uint16_t   CurrPageAddress;
extern uint16_t   CurrBuffByte;

// PROTOTYPES:
uint8_t DF_CheckCorrectOnboardChip(void);
uint8_t DF_GetChipCharacteristics(void);
void    DF_CopyBufferToFlashPage(uint16_t PageAddress);
void    DF_CopyFlashPageToBuffer(uint16_t PageAddress);
void    DF_ContinuousReadEnable(uint16_t PageAddress, uint16_t BuffAddress);
void    DF_BufferWriteEnable(uint16_t BuffAddress);
void    DF_ErasePage(uint16_t PageAddress);

#endif
