#ifndef KEYBOARDSTREAM_H
#define KEYBOARDSTREAM_H

//this function encodes a stream of scancodes from the keyboard, compresses and filters the data via 
//the compression algorithm and calls the appropriate storage functions above.
void encode(uint8_t scancode);

//this function decodes the compressed data previously stored in eeprom and calls sending function in
//ps2device.c
void decodeAndSend(uint8_t size);

//call this function to initialize the buffer before recording macro
void recordReset(void);

//this function returns the size of the macro
uint8_t getSize(void);

//this function provides a read only public interface to the buffer
//i is the index into the buffer, returns the value stored
uint8_t getData(uint8_t i);

//returns the pointer to the location of the buffer
uint8_t* getDataPtr(void);



#endif
