/* eeeprom.c
 * This module manages access to the eeprom 
 * stores data sequentially in eeprom via a packet structure as follows:
 * IRCMD,SIZE(64 bytes max),DATA[0]...DATA[SIZE-1]
 */

#include <avr/io.h>
#include <stdbool.h>
#include <avr/pgmspace.h>
#include <avr/eeprom.h>

#include "utility.h"


//writes 0xFF to all EEPROM memory (device memory cleared state)
void clearEEprom(void){
	uint16_t i;
	for(i=0;i<E2END;i++){							//E2END defined in device header file
		eeprom_write_byte((uint8_t*)i,0xFF);		//write location 0xFF
	}
}


//this function writes the macro data in sram to eeprom free space
//command record is: cmd|size|scancode0|....|scancodeN 
//so the minimum size of record (1 key press) is 3 bytes (with compression)
bool writeMacro(uint8_t scmd, uint8_t ssize, uint8_t *codes){
	uint16_t i=0;									//suport address >255 for tiny85
	uint8_t cmd;
	uint8_t size;


	if(!scmd || !ssize) return 0;					//0 command can not be stored
													//ssize = 0 should not be stored
	if (scmd == 0xFF)									
		scmd = 0;;									//FF indicates un-initialized eeprom, so store a FF as 0 (0 not allowed)

	while(i<=(E2END-3)){ 							//while pointer is less than 3 from the end of eeprom address space
		cmd = eeprom_read_byte((uint8_t*)i);		//read byte from eeprom

		if(cmd == scmd){							//already exists,
			return false;							//return false and exit
		}
		else{
			if (cmd == 0xFF){
				if (((uint8_t)i+ssize+2)<E2END){						//check for sufficient room
					eeprom_write_byte((uint8_t*)i,scmd);				//write ir command
					eeprom_write_byte((uint8_t*)(i+1),ssize);			//write size
					eeprom_write_block(codes,(uint8_t*)(i+2),ssize);	//write macro
					return true;
				}
				else
					return false;										//not enough room
			}
			else{
					size = eeprom_read_byte((uint8_t*)(i+1));			//determine size of current command
					i= i + size + 2;									//increment index beyond current command
			}
		}
	}//end while	
	return false;		
}


//this function searches eeprom for a command
//returns the size of the macro, 0 = not found
//command passed by reference in scmd, pointer to macro array data in *codes 
//uses a linear search to traverse the data to find a match
uint8_t readMacro (uint8_t scmd, uint8_t *codes){
	uint16_t i =0;
	uint8_t cmd;
	uint8_t size;

	if(!scmd) return 0;						//0 command can not be stored
	if (scmd == 0xFF)
		scmd = 0;							//FF indicates un-initialized eeprom, so store a FF as 0 (0 not allowed)



	while(i<=(E2END-3)){ 					//while pointer is less than 3 from the end of eeprom address space
		cmd = eeprom_read_byte((uint8_t*)i);

		if (cmd == 0xFF){					//found un-initialized data, so don't look any further
			return 0;						//not found
		}
		else{
			size = eeprom_read_byte((uint8_t*)(i+1));			//read size
			if(cmd == scmd){									//determine a match
				eeprom_read_block(codes,(uint8_t*)(i+2),size);	//copy from eeprom to static ram
				return size;
			}
			else{										//no match , keep looking
				i = i + size + 2;						//increment pointer beyond current command
			}
		}
	}//end while			
	return 0;											//not found
}


