#ifndef KEYBOARDSTRINGS_H
#define KEYBOARDSTRINGS_H

#include <avr/io.h>
#include <stdbool.h>
//#include <stdio.h>
#include <avr/pgmspace.h>




//this function "types" the character argument via output of keypress scancodes
void kbd_putchar(char ch);

//this function "types" a null terminated string out the keyboard 
void kbd_puts(const char* str);	

//this function "types" a null terminated string (located in prog memory) out the keyboard port
void kbd_puts_P(const char* str);

//"types" the arg byte value in hex
void displayByteVal(uint8_t arg);

#endif
