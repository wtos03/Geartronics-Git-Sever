/* application.c
 * This module provides processing of the high level application and support routines 
 * 
 */

#include <avr/io.h>
#include <stdbool.h>
#include <avr/pgmspace.h>


#include "utility.h"
#include "ps2device.h"
#include "ps2host.h"
#include "keyboardStrings.h"
#include "keyboardStream.h"
#include "eeprom.h"
#include "application.h"
#include "handler2.h"


//this function determines and monitors for the trigger condition to enter programming mode
//from the main application (state 2)
bool appTrigger(uint8_t arg){
static bool begin=false;

	if(!begin){
		if (arg==0x59){
			recordReset();
			encode(arg);
			begin = true;
		}
	}
	else{
		encode(arg);
		//trigger condition is right shift(press and hold),
		// left shift (press and release), right shift (release)
		if (getSize()>=5){	
			begin = false;
			if(	getData(0)==0x08 &&
				getData(1)==0x59 && 
				getData(2)==0x12 && 
				getData(3)==0x18 && 
				getData(4)==0x59)
				return true;
		}
	}
	return false;
}	

//this is the main application that runs continuously and provides high level functionality 
void mainApp(void){
	static uint8_t state=0;
	uint8_t keyCode;
	uint8_t irCmd;
	static uint8_t irCmdMem;
	uint8_t size;
	const char* COMMAND_EQ = PSTR("\n Command = ");

	//endless loop
	while(1){

		switch (state){	
		case 0:	//power on, reset state
			resetHandler();
			state=1;
			break;
		case 1: //normal operation, process keyboard and ir, check for a macro record request
			if(checkKeyboardComs(&keyCode)){	//keyboard has sent a code
				if(appTrigger(keyCode)){
					kbd_puts_P(PSTR("\nPress button on remote to program"));
					state=2;
				}
			}

			processPCtoKeyboard();			//check pc to keyboard (or handle if no attached keyboard) coms

			if(checkIRComms(&irCmd)){
//				inhibitBus(true);
				size = readMacro (irCmd, getDataPtr());
				if (size)
					decodeAndSend(size);
//				inhibitBus(false);		
			}
			break;
		case 2:	//user entered trigger, collect an ir command
			if(checkKeyboardComs(&keyCode)){	//keyboard has sent a code
				if(appTrigger(keyCode)){
					clearEEprom();
					state=1;
				}
			}

			processPCtoKeyboard();			//check pc to keyboard (or handle if no attached keyboard) coms

			if(checkIRComms(&irCmdMem)){
				kbd_puts_P(COMMAND_EQ);
				displayByteVal(irCmdMem);
				kbd_puts_P(PSTR("\n Type in macro now\nPress the same button on remote to accept\n"));
				recordReset();	//reset recorder used to decode trigger
				state=3;
			}
			break;

		case 3:	//ir command is entered, record keyboard macro
			if(checkKeyboardComs(&keyCode)){	//keyboard has sent a code
				encode(keyCode);
			}

			processPCtoKeyboard();			//check pc to keyboard (or handle if no attached keyboard) coms

			if(checkIRComms(&irCmd)){		//check for finish
				kbd_puts_P(COMMAND_EQ);
				displayByteVal(irCmd);		
				if(irCmd==irCmdMem){		//check if same button was press
					kbd_puts_P(PSTR("\nIR command match"));
					if(writeMacro(irCmd, getSize(), getDataPtr()))	//check if macro already exists
						kbd_puts_P(PSTR("\nMacro write OK\n"));
					state = 1;
				}
				else{
					state=2;				//command mismatch, try again
				}		

			}
			break;	
		}//end switch
	}//end while
}
