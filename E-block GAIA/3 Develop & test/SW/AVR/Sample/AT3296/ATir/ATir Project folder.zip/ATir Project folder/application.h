#ifndef APPLICATION_H
#define APPLICATION_H

#include <avr/io.h>
#include <stdbool.h>
#include <avr/pgmspace.h>


#include "utility.h"


//this function determines and monitors for the trigger condition
//to enter programming mode from the main application (state 2)
bool appTrigger(uint8_t arg);


//this is the main application that runs continuously and provides
//high level functionality 
void mainApp(void);

#endif



