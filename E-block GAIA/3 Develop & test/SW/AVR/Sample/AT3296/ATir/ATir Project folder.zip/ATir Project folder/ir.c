//#include "teacRC505.c"

/* This module is used for the ir remote interface.  This module uses
   external interrupt and timer 0 resources.  The IR signal is demodulated by a
   sharp gpium27xk ir demodulators.  pin out is as follows:
   
   				back
   				lenz
   			out	vcc	gnd
   		 
  call the ir_init to setup and enable global interrupts in mainline code
  ir signal is as follows
  
  16 bits address
  8 bits of command
  8 bits of command complimented
  
  signal is as follows:
  
  |_|-|_|---|
  
  interrupt triggers on high to low transitions (sensor normally high with no signal) 1 is low period pulse of 540us, 0 is 
  high period pulse of 1640us, with 570us period between pulses.
  For the Teac RC-505 the address code is 9E79

  for the tiny45, ir input is pin PB0
*/
#include <stdbool.h>
#include <avr/io.h>
#include <avr/interrupt.h>
#include "utility.h"

#define IRPIN PB0

//timer 0 (8 bit), normal mode, /256 clock source, 32us/bit, rollover in 8.192ms
#define t0_on() 			TCCR0B=0x04

//timer 0 timer counter register
#define t0_tc				TCNT0

//reset count to 0
#define t0_reset()			t0_tc=0	

//test if overflow bit is set	
#define t0_ov_test()	 	bit_test(TIFR,TOV0)

//reset overflow bit by writing 1 to it
#define t0_ov_reset()		TIFR = _BV(TOV0)


volatile struct IRFrameType
{
	uint8_t commandc;	//command complement
	uint8_t command;	//ir command
	uint16_t address;	//ir address word
} IRFrame;

uint32_t* IRFramePtr = (uint32_t*) & IRFrame;	//cast the address of the struct as a pointer to 32 bit unsigned int 

volatile bool IRh;	//tracks if a command has been received

//call this to initialize hardware, enable global interrupts in mainline code
void ir_init(){
	PCMSK = 1;						//set up a pin change mask for PB0 only
	bit_set(GIMSK,PCIE);			//pin change interrupt enable
	*IRFramePtr=0;					//initialize pointer
	t0_on();						//start timer 0
}

ISR(PCINT0_vect)
{
	//connect to pin change interrupt masked for BP0 only
	uint8_t deltaTime;
	bool databit;
	static uint8_t recBit;
	if (input(IRPIN) || IRh) { 
		return;	//don't process another receive until last command is read, and only on falling edge
	}

	deltaTime = t0_tc;	//timer accumulated value
	t0_reset();			//reset timer value for next pass

	// 950 1675 2400, us times of interest
	//timer resolution 32us, so divide above times in us by 32 to get timer compare values
	// 30 52 75

	if(t0_ov_test() || (deltaTime < 30) || (deltaTime > 75)){	//pulse not valid
		recBit = 0;
		t0_ov_reset();		//reset overflow flag
		return;	
	}

	if ( deltaTime < 52 )	//short valid puls =
		databit = true;		//logical 1
 	else					//long valid pulse =
		databit = false;	//logical 0

	*IRFramePtr = (*IRFramePtr << 1) | databit;				//shift bit into frame
	if ( ( ++recBit ) == 32 ){								//entire frame received, modify for different frame lengths
		if ( ( IRFrame.command^IRFrame.commandc ) == 0xFF )	//check command vs command complement
			IRh = true;										//valid IR command received mem
	}
}
//this function returns true if a valid IR command has been received	
uint8_t IRhit()
{
	return IRh;
}

//this function returns the command received, only call after IRhit() = true
uint8_t getIRCommand()
{
	IRh = false;			//clear received flag
	return IRFrame.command;	//return the command
}

//this fuction returns the 16 bit remote address command.  This value is unique to the remote used
//Tech RC-505 address is 0x9E79
//uint16_t getIRaddress()
//{
//	return IRFrame.address;
//}


