#ifndef EEPROM_H
#define EEPROM_H

//writes 0xFF to all EEPROM memory (device memory cleared state)
void clearEEprom(void);

//this function writes the macro data in sram to eeprom free space
//command record is: cmd|size|scancode0|....|scancodeN 
//so the minimum size of record (1 key press) is 3 bytes (with compression)
bool writeMacro(uint8_t scmd, uint8_t size, uint8_t *codes);

//this function searches eeprom for a command
//returns the size of the macro, 0 = not found
//command passed by reference in scmd, pointer to macro array data in *codes 
//uses a linear search to traverse the data to find a match
uint8_t readMacro (uint8_t scmd, uint8_t *codes);

#endif
