/* keyboardStream.c
 * This module provides possessing of the keyboard stream, encode and decode of compressed data 
 * Encoding scheme:
 * a compression scheme is used conserve the limited eeprom space of 256 bytes with the tiny 45
 * (512 bytes for tiny 85).  This scheme assumes key press and release sequences are the most common.  Normal
 * key press (3 bytes) is encoded as 1 byte, extended key press (5 bytes) is encoded as 1 byte.
 * key press and release is stored as single byte scancode 
 * if multiple keys are pressed the key down and key release event are encoded as:
 * key down - 0x08 scancode						
 * key release - 0x18 scancode
 * extended codes are stored with the MSB of the scan code high (only one scan code, 0x83, has this condition,
 * so it is a special case and stored as 0x38 to accommodate the extended key encoding scheme)
 * command bytes are not recorded, typematic repeat data is filtered  
 */

#include <avr/io.h>
#include <stdbool.h>
#include <avr/pgmspace.h>


#include "utility.h"
#include "ps2device.h"
#include "keyboardStream.h"

//64 bytes storage for an individual macro, also used to store recorded macro data from eeprom to transmit out
#define BUFSIZE 64	

static uint8_t keybuf[BUFSIZE];		//allocate buffer space 
static uint8_t indx;				//index

//these functions manipulate storage to keybuf, store then inc index, valid index 0-(BUFSIZE-1)
//this function stores a normal (non extended key) key press (press and release sequence)
void addKeyPress(uint8_t arg){
	if (indx<(BUFSIZE-1)){
		if(arg == 0x83) arg = 0x38;	//1 special case where msbit of a scan code is high
		keybuf[indx++]=arg;
	}
}

//this function stores an extended key press
void addKeyPressExt(uint8_t arg){
	if (indx<(BUFSIZE-1)){
		bit_set(arg,7);			//set msbit high
		keybuf[indx++]=(arg);
	}		
}

//this fuction stores a key down event
void addKeyDown(uint8_t arg){
	if (indx<(BUFSIZE-2)){
		if(arg == 0x83) arg = 0x38;	//1 special case where msbit of a scan code is high
		keybuf[indx++]=0x08;	//key down special code (not a keycode)	
		keybuf[indx++]=(arg);
	}		
}

//this function stores an extended key down event 
void addKeyDownExt(uint8_t arg){
	if (indx<(BUFSIZE-2)){
		bit_set(arg,7);			//set msbit high
		keybuf[indx++]=0x08;	//key down special code (not a keycode)	
		keybuf[indx++]=(arg);
	}		
}

//this fuction stores a key release event
void addKeyRelease(uint8_t arg){
	if (indx<(BUFSIZE-2)){
		if(arg == 0x83) arg = 0x38;	//1 special case where msbit of a scan code is high
		keybuf[indx++]=0x18;	//key release special code (not a keycode)	
		keybuf[indx++]=(arg);
	}		
}

//this function stores an extended key release event
void addKeyReleaseExt(uint8_t arg){
	if (indx<(BUFSIZE-2)){
		bit_set(arg,7);			//set msbit high
		keybuf[indx++]=0x18;	//key down special code (not a keycode)	
		keybuf[indx++]=(arg);
	}		
}

//this function encodes a stream of scancodes from the keyboard, compresses and filters the data via 
//the compression algorithm and calls the appropriate storage functions above.
void encode(uint8_t scancode){
static bool ext = false;	//extended key flag
static bool rel = false;	//key release flag
static bool lwc = false;	//last (input) was a code byte (not ext or rel)

static uint8_t lastcode = 0;


	switch (scancode){
	case 0xE0:
		if (lastcode && !ext){
			addKeyDown(lastcode);
			lastcode = 0;
		}
		ext = true;
		lwc = false;
		break;
	case 0xF0:
		rel = true;
		lwc = false;
		break;
	default:
		if (scancode==lastcode){
			if(rel){				//if release, its a keypress
				rel=false;
				if(ext){
					ext = false;
					addKeyPressExt(lastcode);
				}
				else{
					addKeyPress(lastcode);
				}
				lastcode = 0;
			}
			else{
				if(ext && lwc){
					addKeyDownExt(lastcode);
					ext = false;	

				}
			}
		}
		else{//scancode != lastcode
			if(lastcode){	//a key was pressed pending
				if(rel){
					rel=false;
					if(ext){
						ext = false;
						addKeyDownExt(lastcode);
						addKeyReleaseExt(scancode);
					}
					else{
						addKeyDown(lastcode);
						addKeyRelease(scancode);
					}
					lastcode=0;
				}
				else{
					if(ext){
						addKeyDownExt(lastcode);
						
						if(lwc)
							ext = false;
					}
					else{
						addKeyDown(lastcode);
					}
				lastcode=scancode;
				}


			}
			else{	//key not pressed pending
				if(rel){
					rel = false;
					if(ext){
						ext = false;
						addKeyReleaseExt(scancode);
					}
					else{
						addKeyRelease(scancode);
					}
				lastcode=0;
					
				}
				else{

				lastcode=scancode;
				}
			}
		}
	lwc=true;
	}//end switch

}
//this function decodes the compressed data previously stored in eeprom and calls sending function in
//ps2device.c
void decodeAndSend(uint8_t size){
	uint8_t i=0;
	uint8_t val;
	while(i<size){
		val=keybuf[i++];
		switch (val){
			case 0x08:			//key down
				val=keybuf[i++];
				if(bit_test(val,7))
					keyDownExt(bit_clear(val,7));
				else{
					if(val == 0x38) val = 0x83;
					keyDown(val);
				}
				break;
			case 0x18:			//key release
				val=keybuf[i++];
				if(bit_test(val,7))
					keyReleaseExt(bit_clear(val,7));
				else{
					if(val == 0x38) val = 0x83;
					keyRelease(val);
				}
				break;
			default:			//key press
				if(bit_test(val,7))
					keyPressExt(bit_clear(val,7));
				else{
					if(val == 0x38) val = 0x83;
					keyPress(val);
				}
		}//end switch
	}//end while
		
}

//call this function to initialize the buffer before recording macro
void recordReset(void){
	indx=0;
}

//this function returns the size of the macro
uint8_t getSize(void){
	return indx;
}

//this function provides a read only public interface to the buffer
//i is the index into the buffer, returns the value stored 
uint8_t getData(uint8_t i){
	return keybuf[i];
}

//returns the pointer to the location of the buffer
uint8_t* getDataPtr(void){
	return keybuf;
}
