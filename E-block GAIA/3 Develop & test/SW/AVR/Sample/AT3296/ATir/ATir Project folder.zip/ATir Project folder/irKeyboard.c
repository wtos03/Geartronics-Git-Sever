//irKeyboard.c  
//program entry point

#include <avr/io.h>	//included so we can use the text label for ports, pins etc.
#include <avr/interrupt.h>
#include <avr/wdt.h>	//included so we can call the function wdt_disable();



#include "ir.h"
#include "ps2host.h"
#include "ps2device.h"
#include "utility.h"
#include "application.h"


void main(){
//	wdt_disable();		//disable watchdog

	ir_init();			//initialize ir hardware
	device_init();		//initialize keyboard emulation hardware
	host_init();		//initialize pc host hardware
	sei();				// enable interrupts

//	wdt_enable(WDTO_500MS);	//enable watchdog for 500ms timeout
	mainApp();			//call the main application

}
