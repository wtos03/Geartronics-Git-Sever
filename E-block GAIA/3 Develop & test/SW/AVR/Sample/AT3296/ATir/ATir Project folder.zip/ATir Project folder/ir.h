#ifndef IR_H
#define IR_H
//#include "teacRC505.c"

/* This module is used for the IR remote interface.  This module uses
   external interrupt and timer 0 resources.  The IR signal is demodulated by a
   sharp GPIUM27XK IR demodulators.  pinout is as follows:
   
   				back
   				lenz
   		out	vcc	gnd
   		 
  call the ir_init to setup and enable global interrupts in mainline code
  ir signal is as follows
  
  16 bits address
  8 bits of command
  8 bits of command complimented
  
  signal is as follows:
  
  |_|-|_|---|
  
  interrupt triggers on high to low transitions (sensor normally high with no signal) 1 is low period pulse of 540us, 0 is 
  high period pulse of 1640us, with 570us period between pulses.
  For the Teac RC-505 the address code is 9E79
*/

//call this to initialize hardware, enable global interrupts in mainline code
void ir_init();

//this function returns true if a valid IR command has been received	
uint8_t IRhit();

//this function returns the command received, only call after IRhit() = true
uint8_t getIRCommand();

//this function returns the 16 bit remote address command.  This value is unique to the remote used
//Tech RC-505 address is 0x9E79
uint16_t getIRaddress();

#endif
