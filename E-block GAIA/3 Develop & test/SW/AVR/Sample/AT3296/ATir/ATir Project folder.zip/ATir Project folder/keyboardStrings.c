/* keyboardStrings.c
 * This module translates a limited mapping of ascii characters to keyboard scancodes via lookup table
 * Also includes a putch and puts implementation that sends characters and strings to the computer via
 * the keyboard interface as if they were typed.  Table supports upper and lower case characters and 
 * numeric characters, as well as many special characters.  Table is encoded with the most significant bit set
 * if the shift key should be used to "type" the character (such as typing an upper case letter).
 */


#include <avr/io.h>
#include <stdbool.h>
#include <avr/pgmspace.h>

#include "utility.h"
#include "ps2device.h"
#include "keyboard.h"
#include "keyboardStrings.h"

//this table is stored in program memory
const uint8_t codeTable[64] __attribute__((section(".progmem"))) = { 	
	41	,//	0	 
	150	,//	1	!
	171	,//	2	"
	166	,//	3	#
	165	,//	4	$
	174	,//	5	%
	189	,//	6	&
	142	,//	7	'
	198	,//	8	(
	197	,//	9	)
	190	,//	10	*
	213	,//	11	+
	65	,//	12	,
	78	,//	13	-
	73	,//	14	.
	74	,//	15	/
	69	,//	16	0
	22	,//	17	1
	30	,//	18	2
	38	,//	19	3
	37	,//	20	4
	46	,//	21	5
	54	,//	22	6
	61	,//	23	7
	62	,//	24	8
	70	,//	25	9
	204	,//	26	:
	76	,//	27	;
	193	,//	28	<
	85	,//	29	=
	201	,//	30	>
	202	,//	31	?
	158	,//	32	@
	156	,//	33	A
	178	,//	34	B
	161	,//	35	C
	163	,//	36	D
	164	,//	37	E
	171	,//	38	F
	180	,//	39	G
	179	,//	40	H
	195	,//	41	I
	187	,//	42	J
	194	,//	43	K
	203	,//	44	L
	186	,//	45	M
	177	,//	46	N
	196	,//	47	O
	205	,//	48	P
	149	,//	49	Q
	173	,//	50	R
	155	,//	51	S
	172	,//	52	T
	188	,//	53	U
	170	,//	54	V
	157	,//	55	W
	162	,//	56	X
	181	,//	57	Y
	154	,//	58	Z
	84	,//	59	[
	93	,//	60	
	91	,//	61	]
	182	,//	62	^
	206	 //	63	_
};

//this function displays the argument as a hex character string
void displayByteVal(uint8_t arg){
	uint8_t temp;
	char ch;
	temp= arg>>4;
	ch=toHexChar(temp);
	kbd_putchar(ch);
	ch=toHexChar(arg);
	kbd_putchar(ch);
}					


//this function "types" the character argument via output of keypress scancodes
void kbd_putchar(char ch){
	uint8_t index;
	uint8_t keyCode;
	bool shift = false;	
	switch (ch){
	case ('\n'):
		keyPress(KEY_ENTER);
		break;
	case ('\t'):
		keyPress(KEY_TAB);
		break;

	default:

		index=ch-32;				//subtract 32 from ascii value to obtain index
		if (index>63){				//lower case letters and supported symbols greater than 63
			index-=32;				// are equiv to value - 32 but with shift inverted
			shift = true;			//after xor, shift is inverted
		}
		keyCode=pgm_read_byte(codeTable + index);
		if bit_test(keyCode,7){
			shift^=true;			//set shift or invert if already 1
			bit_clear(keyCode,7);
		}

		if (shift){					//this section presses the shift key for every character
			keyDown(KEY_SHIFT);
			keyPress(keyCode);
			keyRelease(KEY_SHIFT);
		}
		else
			keyPress(keyCode);		//non shift keypress
	
		break;
	}//end switch
}

//this function "types" a string via kbd_putch above, string must be located in program memory
void kbd_puts_P(const char* str){ 
	char ch;
	do{
		ch=pgm_read_byte(str++);	//read byte from program memory
		if (ch)						//look for null to terminate string
			kbd_putchar(ch);		//output character
		}while(ch);					//loop until null
}
