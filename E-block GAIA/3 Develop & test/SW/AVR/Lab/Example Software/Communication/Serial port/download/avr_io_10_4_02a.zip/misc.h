//misc.h

#ifndef misc_h
#define misc_h

typedef unsigned char  BYTE;
typedef char           SBYTE;
typedef unsigned int   WORD16;
typedef int            SWORD16;
typedef unsigned long  WORD32;
typedef long           SWORD32;

#define TRUE		1
#define FALSE  0

#endif //misc_h
